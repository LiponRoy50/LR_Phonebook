package com.example.lipon.lr_phonebook.recyclerview;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lipon.lr_phonebook.model.Data_sqlite;
import com.example.lipon.lr_phonebook.R;
import com.example.lipon.lr_phonebook.Activitys.Show_DetailsAll;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {



    private ArrayList<Data_sqlite> dataSet;
    private Context context;


    public CustomAdapter(ArrayList<Data_sqlite> data,Context context) {
        this.dataSet = data;
        this.context=context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);

        //view.setOnClickListener(Main2Activity.myOnClickListener);

        MyViewHolder myViewHolder = new MyViewHolder(view,dataSet,context);

        return myViewHolder;
    }


    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int listPosition) {

        Data_sqlite data_sqlite = dataSet.get(listPosition);

        byte[] Bimage =data_sqlite.getImg();
        Bitmap bitmap = BitmapFactory.decodeByteArray(Bimage,0,Bimage.length);
        holder.textImage.setImageBitmap(bitmap);

        holder.textViewName.setText(data_sqlite.getName());
        holder.textViewPhone.setText(data_sqlite.getPhoneNumber());
        holder.textViewEmail.setText(data_sqlite.getEmail());



    }



    @Override
    public int getItemCount() {
        return dataSet.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ImageView textImage;
        TextView textViewName;
        TextView textViewPhone;
        TextView textViewEmail;

        // for click letionar
        private ArrayList<Data_sqlite> dataSetClick;
        private Context con;





        public MyViewHolder(View itemView,ArrayList<Data_sqlite> dataSe,Context con) {
            super(itemView);

            itemView.setOnClickListener(this);
            this.dataSetClick = dataSe;
            this.con=con;


            this.textImage = (ImageView) itemView.findViewById(R.id.RcV_image);
            this.textViewName = (TextView) itemView.findViewById(R.id.RcV_Name);
            this.textViewPhone = (TextView) itemView.findViewById(R.id.RcV_Phone);
            this.textViewEmail = (TextView) itemView.findViewById(R.id.RcV_Email);


        }


        @Override
        public void onClick(View v) {

            int pos =getAdapterPosition();

            Intent intent = new Intent(con,Show_DetailsAll.class);
            intent.putExtra("imagg",dataSetClick.get(pos).getImg());
            intent.putExtra("nameOfmy",dataSetClick.get(pos).getName());
            intent.putExtra("phn",dataSetClick.get(pos).getPhoneNumber());
            intent.putExtra("eml",dataSetClick.get(pos).getEmail());
            intent.putExtra("position",pos);

            con.startActivity(intent);



        }

    }







}