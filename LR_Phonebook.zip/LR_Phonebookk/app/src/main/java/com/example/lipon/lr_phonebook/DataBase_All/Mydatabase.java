package com.example.lipon.lr_phonebook.DataBase_All;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.MediaStore;
import android.widget.Toast;

import com.example.lipon.lr_phonebook.Activitys.MainActivity;
import com.example.lipon.lr_phonebook.Activitys.Show_DetailsAll;
import com.example.lipon.lr_phonebook.Activitys.Update_From;
import com.example.lipon.lr_phonebook.model.Data_sqlite;

import java.util.ArrayList;


public class Mydatabase extends SQLiteOpenHelper {
    Context cont;

    public Mydatabase(Context context) {
        super(context, Constances.DATABASE_NAME, null, Constances.VERSION);
        this.cont=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

      db.execSQL(Constances.Stable);


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Constances.TABLE_NAME);
        onCreate(sqLiteDatabase);

    }


    public boolean InsertData(Data_sqlite data_sqlite){

        SQLiteDatabase sd =this.getWritableDatabase();
        ContentValues conV = new ContentValues();

        conV.put(Constances.IMAGE_FIELD,data_sqlite.getImg());
        conV.put(Constances.NAME_FIELD,data_sqlite.getName());
        conV.put(Constances.PHONE_NUMBER_FIELD,data_sqlite.getPhoneNumber());
        conV.put(Constances.EMIL_FIELD,data_sqlite.getEmail());

       long num= sd.insert(Constances.TABLE_NAME,null,conV);
        sd.close();

       if(num==-1){

           return  false;


       }else{
           return true;

       }

    };



    public ArrayList<Data_sqlite> Display_Data(){

        ArrayList<Data_sqlite> al = new ArrayList<>();

        SQLiteDatabase sqd = this.getReadableDatabase();

        Cursor cursor = sqd.query(Constances.TABLE_NAME,null,null,null,null,null,null);

        if(cursor!=null && cursor.getCount()>0){

            cursor.moveToFirst();

            for(int i=0;i<cursor.getCount();i++){

                byte[] imgBB =cursor.getBlob(cursor.getColumnIndex(Constances.IMAGE_FIELD));
                String Name =cursor.getString(cursor.getColumnIndex(Constances.NAME_FIELD));
                String Phone =cursor.getString(cursor.getColumnIndex(Constances.PHONE_NUMBER_FIELD));
                String Email =cursor.getString(cursor.getColumnIndex(Constances.EMIL_FIELD));


                Data_sqlite data_sqlite = new Data_sqlite(imgBB,Name,Phone,Email);
                al.add(data_sqlite);

                cursor.moveToNext();

            }

        }else{

            Toast.makeText(cont,"Both requred",Toast.LENGTH_LONG).show();
        }

        sqd.close();
        cursor.close();
        return al;
    }

    public void deleteItem(String IDM){


        SQLiteDatabase sqd = this.getReadableDatabase();

        sqd.delete(Constances.TABLE_NAME,Constances.NAME_FIELD+ " =?",new String[]{IDM});
        sqd.close();





    }

    public void UpdateData(Data_sqlite data_sqlite,String Namee){

        SQLiteDatabase sqd = this.getWritableDatabase();
        ContentValues con = new ContentValues();

        con.put(Constances.IMAGE_FIELD,data_sqlite.getImg());
        con.put(Constances.NAME_FIELD,data_sqlite.getName());
        con.put(Constances.PHONE_NUMBER_FIELD,data_sqlite.getPhoneNumber());
        con.put(Constances.EMIL_FIELD,data_sqlite.getEmail());

        sqd.update(Constances.TABLE_NAME,con,Constances.NAME_FIELD+ " =?",new String[]{Namee});

    sqd.close();

    }




















}

































