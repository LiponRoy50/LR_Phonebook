package com.example.lipon.lr_phonebook.Activitys;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.lipon.lr_phonebook.R;

public class Email_Send_Activity extends AppCompatActivity {

    private EditText To_Edt;
    private EditText Subject_Edt;
    private EditText Message_Edt;
    private Button Send_But;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email__send_);

        To_Edt = findViewById(R.id.edit_text_to);
        Subject_Edt = findViewById(R.id.edit_text_subject);
        Message_Edt = findViewById(R.id.edit_text_message);

        To_Edt.setText(getIntent().getExtras().getString("Email_em"));

        Send_But= findViewById(R.id.button_send);
        Send_But.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMail();
            }
        });


    }

    private void sendMail() {
        String To_Email = To_Edt.getText().toString();
        String subject = Subject_Edt.getText().toString();
        String message = Message_Edt.getText().toString();

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, To_Email);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, message);

        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent, "Choose an email client"));
    }




}
