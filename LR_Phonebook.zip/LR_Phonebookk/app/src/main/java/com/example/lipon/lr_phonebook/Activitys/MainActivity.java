package com.example.lipon.lr_phonebook.Activitys;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.lipon.lr_phonebook.model.Data_sqlite;
import com.example.lipon.lr_phonebook.DataBase_All.Mydatabase;
import com.example.lipon.lr_phonebook.R;
import com.example.lipon.lr_phonebook.recyclerview.CustomAdapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Mydatabase mydatab;
    Data_sqlite data_sqlite;

    //for RecycelerView
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<Data_sqlite> Arr_data_sqlite;
    //for RecycelerView End


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //for RecycelerView
        // initialize array list
        Arr_data_sqlite = new ArrayList<>();  // this is very important otherwaya error show
        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_viewTwo);

        ForRecycelerView();
        //for RecycelerView End

    }

    void ForRecycelerView(){


//        // add data into Arrylist
//        dataSet.add( new DataAll("Pukur","O17340","Jabo"));
//        dataSet.add( new DataAll("Pukur","O27340","Jabo"));
//        dataSet.add( new DataAll("Pukur","O37340","Jabo"));
//        dataSet.add( new DataAll("Pukur","O47340","Jabo"));
//        dataSet.add( new DataAll("Pukur","O57340","Jabo"));
//        dataSet.add( new DataAll("Pukur","O67340","Jabo"));
//        dataSet.add( new DataAll("Pukur","O77340","Last"));
        mydatab=new Mydatabase(getApplicationContext());
        Arr_data_sqlite=mydatab.Display_Data();



        recyclerView.setHasFixedSize(true);
        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        mAdapter = new CustomAdapter(Arr_data_sqlite,MainActivity.this);
        recyclerView.setAdapter(mAdapter);


    }


    // for actionBar Add button
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.actionforlipon,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.AddBut){

            Intent i = new Intent(MainActivity.this, Add_Contact_Activity.class);
            startActivity(i);

        }

        return super.onOptionsItemSelected(item);
    }

    // for actionBar Add button End
}
