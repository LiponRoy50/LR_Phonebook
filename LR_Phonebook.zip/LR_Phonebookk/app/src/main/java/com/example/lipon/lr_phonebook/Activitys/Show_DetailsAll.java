package com.example.lipon.lr_phonebook.Activitys;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lipon.lr_phonebook.DataBase_All.Mydatabase;
import com.example.lipon.lr_phonebook.R;

import static com.example.lipon.lr_phonebook.R.*;

public class Show_DetailsAll extends AppCompatActivity {

    ImageView imageView;
    TextView show_name,show_phn,show_email;
    Button Call_But,Email_But;
    byte[] mybyte;
    Bitmap bitmap;

    Mydatabase mydatab;

    String Sname,SPhone,SEmail;
    // for phone call
    private static final int REQUEST_CALL = 11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_show__details_all);

        show_name=(TextView)findViewById(id.Show_Name);
        show_phn=(TextView)findViewById(id.Show_Phone);
        show_email=(TextView)findViewById(id.Show_Email);
        imageView = (ImageView)findViewById(id.Show_imageView);
        Call_But=findViewById(id.Call_button);
        Email_But=findViewById(id.Email_button);

        show_name.setText(getIntent().getExtras().getString("nameOfmy"));
        show_phn.setText(getIntent().getExtras().getString("phn"));
        show_email.setText(getIntent().getExtras().getString("eml"));

        Sname= show_name.toString();

       // Click_Position=getIntent().getExtras().getInt("position"); // for update or delete mathod

        mybyte = getIntent().getExtras().getByteArray("imagg");
        bitmap = BitmapFactory.decodeByteArray(mybyte,0,mybyte.length);
        imageView.setImageBitmap(bitmap);

        // for call to number
        Call_But.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                makePhoneCall();

            }
        });

        // Email send
        Email_But.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Show_DetailsAll.this, Email_Send_Activity.class);
                i.putExtra("Email_em",show_email.getText().toString());
                startActivity(i);

            }
        });


    }


    // for actionBar show button

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.update_delete_but,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()== id.DeleteBut){

            final AlertDialog.Builder aleart =new AlertDialog.Builder(Show_DetailsAll.this);
                  aleart.setTitle("Dlete Option");
                  aleart.setMessage("Wanna Delete it ?");
                  aleart.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                          String name =show_name.getText().toString();
                          mydatab = new Mydatabase(getApplicationContext());
                          mydatab.deleteItem(name);
                          // go back List item in Main Activity
                          Intent i = new Intent(Show_DetailsAll.this, MainActivity.class);
                          startActivity(i);
                        //  Toast.makeText(getApplicationContext(),pos+" has deleted",Toast.LENGTH_LONG).show();



                      }
                  });
                  aleart.setNegativeButton("No", new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {

                          finish();
                      }
                  });
                  aleart.show();


        }else if(item.getItemId()== id.UpdateBut){

            //show_Update_Dialouge(Show_DetailsAll.this,Sname);

           // Toast.makeText(getApplicationContext()," has deleted",Toast.LENGTH_LONG).show();

            Intent i = new Intent(Show_DetailsAll.this, Update_From.class);
            Sname = show_name.getText().toString();
            SPhone = show_phn.getText().toString();
            SEmail= show_email.getText().toString();
            i.putExtra("nameMy",Sname);
            i.putExtra("phoneMy",SPhone);
            i.putExtra("emailMy",SEmail);
            i.putExtra("imageMy",mybyte);
            startActivity(i);

        }

        return super.onOptionsItemSelected(item);
    }
    // for actionBar show button End



   // make phone call
    private void makePhoneCall() {
        String number = show_phn.getText().toString();
        if (number.trim().length() > 0) {

            if (ContextCompat.checkSelfPermission(Show_DetailsAll.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(Show_DetailsAll.this,
                        new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
            } else {
                String dial = "tel:" + number;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }

        } else {
            Toast.makeText(Show_DetailsAll.this, "Enter Phone Number", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }




//    void show_Update_Dialouge(Activity activity,String name){
//
//        final Dialog dialog = new Dialog(activity);
//        dialog.setContentView(layout.update_dialouge);
//        dialog.setTitle("Update all");
//
//        EditText editName =findViewById(id.UpD_Name);
//        EditText editPhone =findViewById(id.UpD_Phone);
//        EditText editEmail =findViewById(id.UpD_Email);
//        Button button = findViewById(id.UpD_button);
//
//        //set width
//        int width =(int)(activity.getResources().getDisplayMetrics().widthPixels*0.95);
//        // set height
//        int height =(int)(activity.getResources().getDisplayMetrics().widthPixels*0.7);
//
//        dialog.getWindow().setLayout(width,height);
//        dialog.show();
//
//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//              dialog.dismiss();
//
//
//
//            }
//        });
//
//    }

}
