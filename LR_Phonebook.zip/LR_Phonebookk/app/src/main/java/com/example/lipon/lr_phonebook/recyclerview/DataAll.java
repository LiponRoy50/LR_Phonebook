package com.example.lipon.lr_phonebook.recyclerview;

public class DataAll {

    String  NameMe,
            UsernameMe,
            PasswordMe;


    public DataAll(String nameMe, String usernameMe, String passwordMe) {
        NameMe = nameMe;
        UsernameMe = usernameMe;
        PasswordMe = passwordMe;

    }


    public String getNameMe() {
        return NameMe;
    }

    public String getUsernameMe() {
        return UsernameMe;
    }

    public String getPasswordMe() {
        return PasswordMe;
    }





}
