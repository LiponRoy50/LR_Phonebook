package com.example.lipon.lr_phonebook.Activitys;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.lipon.lr_phonebook.DataBase_All.Mydatabase;
import com.example.lipon.lr_phonebook.R;
import com.example.lipon.lr_phonebook.model.Data_sqlite;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;

public class Update_From extends AppCompatActivity {

    ImageView Up_Image;
    EditText Up_name,Up_phone,Up_email;
    Button Up_But;

       Mydatabase mydatab;
      Data_sqlite data_sqlite;
      byte[] mybyte;

   String nm,phN,email;

  String UpdateName,UpdatePhone,UpdateEmail;

    // for Camera photo
    final int Camera_Pic_Code= 100;
    final int Camera_Permisson_Code= 200;
    //Bitmap bitmap_Camera;
    //for gelory photo
    final int Image_Pic_Code= 300;
    final int Image_Permisson_Code= 400;
    // Bitmap bitmap_gelory;

    // Progress Bar
    private ProgressDialog progressBar;
    private int progressBarStatus = 0;
    private Handler progressBarbHandler = new Handler();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update__from);

        Up_Image=findViewById(R.id.Update_imageView);
        Up_name=findViewById(R.id.Update_Name);
        Up_phone=findViewById(R.id.Update_Phone);
        Up_email=findViewById(R.id.Update_Email);
        Up_But=findViewById(R.id.Update_Button);


        UpdateName =getIntent().getExtras().getString("nameMy");
        UpdatePhone =getIntent().getExtras().getString("phoneMy");
        UpdateEmail =getIntent().getExtras().getString("emailMy"); //imageMy

        mybyte = getIntent().getExtras().getByteArray("imageMy");
        Bitmap bitmap = BitmapFactory.decodeByteArray(mybyte,0,mybyte.length);
        Up_Image.setImageBitmap(bitmap);


        // Just show list data
        Up_name.setText(UpdateName);
        Up_phone.setText(UpdatePhone);
        Up_email.setText(UpdateEmail);

        UpdateDataRow();


        Up_Image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Update_Image();
            }
        });


    }

    void UpdateDataRow(){


        Up_But.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //String Id= String.valueOf(posss);
                nm=Up_name.getText().toString();
                phN=Up_phone.getText().toString();
                email=Up_email.getText().toString();

                // for image to byte array to insert image to sqlite
                byte[] imageByteMe = imageViewToByte(Up_Image);

                if(TextUtils.isEmpty(email) || TextUtils.isEmpty(nm) || TextUtils.isEmpty(phN)){

                    Toast.makeText(getApplicationContext(),"Enter all item",Toast.LENGTH_LONG).show();

                }else{

                    data_sqlite= new Data_sqlite(imageByteMe,nm,phN,email);
                    mydatab = new Mydatabase(getApplicationContext());
                    mydatab.UpdateData(data_sqlite,UpdateName);
                    // go back List item in Main Activity
                    Intent i = new Intent(Update_From.this, MainActivity.class);
                    startActivity(i);



                }


            }
        });


    }



    //For Pick image from Camera or Gelory------------------
    private void Update_Image() {       // Dorkar hole custom Aleart dialogue use korlam
        final CharSequence[] options = { "Take Photo", "Choose from Gallery","Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(Update_From.this);
        builder.setTitle("Add Photo!");
        builder.setCancelable(false);

        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo"))
                {
                    Take_Camera_PERMISSION();
                }
                else if (options[item].equals("Choose from Gallery"))
                {
                    Gallery_pic_PERMISSION();
                }
                else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }
    void Take_Camera_PERMISSION(){


        //  now check the permission

        if(Build.VERSION.SDK_INT >=Build.VERSION_CODES.M){

            if(checkSelfPermission(Manifest.permission.CAMERA)== PackageManager.PERMISSION_DENIED){

                // permission not grented request for permission

                String[] permissions ={Manifest.permission.CAMERA};
                // show pop up for runtime permission
                requestPermissions(permissions,Camera_Permisson_Code);

            }else{

                // permission already grented
                Cemera_Open();

            }

        }else{
            // System CAMERA is les then Masmallow
            Cemera_Open();

        }

    }
    void Gallery_pic_PERMISSION(){


        //  now check the permission

        if(Build.VERSION.SDK_INT >=Build.VERSION_CODES.M){

            if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_DENIED){

                // permission not grented request for permission

                String[] permissions ={Manifest.permission.READ_EXTERNAL_STORAGE};
                // show pop up for runtime permission
                requestPermissions(permissions,Image_Permisson_Code);

            }else{

                // permission already grented
                Gallery_Open();

            }

        }else{
            // System image is les then Masmallow
            Gallery_Open();

        }



    }
    void Cemera_Open(){

        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(i, Camera_Pic_Code);

    }
    void Gallery_Open() {

        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, Image_Pic_Code);

    }

    //  aeta permission er jonno Ajira code
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode==Camera_Permisson_Code){

            if(grantResults.length>=0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){

                Cemera_Open();
            }else{

                Toast.makeText(Update_From.this,"Permission Denied",Toast.LENGTH_LONG).show();
            }


        }else if(requestCode==Image_Permisson_Code){
            if(grantResults.length>=0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){

                Gallery_Open();
            }else{

                Toast.makeText(Update_From.this,"Permission Denied",Toast.LENGTH_LONG).show();
            }

        }


        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Camera_Pic_Code && resultCode == RESULT_OK) {

            Bitmap bitmap_Camera = (Bitmap) data.getExtras().get("data");
            Glide
                    .with(Update_From.this)
                    .load(bitmap_Camera)
                    .override(400,400)
                    .into(Up_Image);


        }
        else if(requestCode == Image_Pic_Code && resultCode == RESULT_OK){
            if(data!=null){

                Uri imgUri = data.getData();
                CropImage.activity(imgUri)
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setAspectRatio(1,1)
                        .start(this);
//
//                    Glide
//                            .with(Add_Contact_Activity.this)
//                            .load(bitmap_gelory)
//                            .override(400,400)
//                            .into(AddCon_Image);


            }

        }if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();
                Glide
                        .with(Update_From.this)
                        .load(resultUri)
                        .override(400,400)
                        .into(Up_Image);
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }



    }



    //For Pick image from Camera or Gelory End----------------------

    public byte[] imageViewToByte(ImageView img){

        Bitmap bitmap =((BitmapDrawable)img.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100,stream);
        byte[] ImagByte =stream.toByteArray();

        return ImagByte;



    }





}
