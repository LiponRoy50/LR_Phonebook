package com.example.lipon.lr_phonebook.Activitys;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.lipon.lr_phonebook.model.Data_sqlite;
import com.example.lipon.lr_phonebook.DataBase_All.Mydatabase;
import com.example.lipon.lr_phonebook.R;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class Add_Contact_Activity extends AppCompatActivity {

    EditText AddCon_name,AddCon_phone,AddCon_email;
    Button AddCon_But;

    Mydatabase mydatab;
    Data_sqlite data_sqlite;

    ImageView AddCon_Image;
    // for Camera photo
    final int Camera_Pic_Code= 100;
    final int Camera_Permisson_Code= 200;
    //Bitmap bitmap_Camera;
    //for gelory photo
    final int Image_Pic_Code= 300;
    final int Image_Permisson_Code= 400;
   // Bitmap bitmap_gelory;

    // Progress Bar
    private ProgressDialog progressBar;
    private int progressBarStatus = 0;
    private Handler progressBarbHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__contact_);

        AddCon_Image=findViewById(R.id.Add_Con_imageView);

        AddCon_name=findViewById(R.id.Add_Con_Name);
        AddCon_phone=findViewById(R.id.Add_Con_Phone);
        AddCon_email=findViewById(R.id.Add_Con_Email);
        AddCon_But=findViewById(R.id.Add_Con_Button);

        AddData();

        AddCon_Image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });

    }

    void AddData(){
        AddCon_But.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name= AddCon_name.getText().toString();
                String phoneNumber=AddCon_phone.getText().toString();
                String Email=AddCon_email.getText().toString();
                byte[] imageByteMe = imageViewToByte(AddCon_Image);


                if(TextUtils.isEmpty(name) || TextUtils.isEmpty(phoneNumber) || TextUtils.isEmpty(Email)){

                    Toast.makeText(getApplicationContext(),"Plz Enter all field",Toast.LENGTH_LONG).show();

                }else{

                    data_sqlite= new Data_sqlite(imageByteMe,name,phoneNumber,Email);
                    mydatab = new Mydatabase(getApplicationContext());

                    if(mydatab.InsertData(data_sqlite)){
                        Toast.makeText(getApplicationContext(),"Data inserted ",Toast.LENGTH_LONG).show();

                    }else{
                        Toast.makeText(getApplicationContext(),"Not inserted",Toast.LENGTH_LONG).show();
                    }

                }


            }
        });


    }
    // End of AddData()

    //For Pick image from Camera or Gelory------------------
    private void selectImage() {       // Dorkar hole custom Aleart dialogue use korlam
        final CharSequence[] options = { "Take Photo", "Choose from Gallery","Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(Add_Contact_Activity.this);
        builder.setTitle("Add Photo!");
        builder.setCancelable(false);

        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo"))
                {
                    Take_Camera_PERMISSION();
                }
                else if (options[item].equals("Choose from Gallery"))
                {
                    Gallery_pic_PERMISSION();
                }
                else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }
    void Take_Camera_PERMISSION(){


        //  now check the permission

        if(Build.VERSION.SDK_INT >=Build.VERSION_CODES.M){

            if(checkSelfPermission(Manifest.permission.CAMERA)== PackageManager.PERMISSION_DENIED){

                // permission not grented request for permission

                String[] permissions ={Manifest.permission.CAMERA};
                // show pop up for runtime permission
                requestPermissions(permissions,Camera_Permisson_Code);

            }else{

                // permission already grented
                Cemera_Open();

            }

        }else{
            // System CAMERA is les then Masmallow
            Cemera_Open();

        }

    }
    void Gallery_pic_PERMISSION(){


        //  now check the permission

        if(Build.VERSION.SDK_INT >=Build.VERSION_CODES.M){

            if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_DENIED){

                // permission not grented request for permission

                String[] permissions ={Manifest.permission.READ_EXTERNAL_STORAGE};
                // show pop up for runtime permission
                requestPermissions(permissions,Image_Permisson_Code);

            }else{

                // permission already grented
                Gallery_Open();

            }

        }else{
            // System image is les then Masmallow
            Gallery_Open();

        }



    }
    void Cemera_Open(){

        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(i, Camera_Pic_Code);

    }
    void Gallery_Open() {

        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, Image_Pic_Code);

    }

    //  aeta permission er jonno Ajira code
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode==Camera_Permisson_Code){

            if(grantResults.length>=0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){

                Cemera_Open();
            }else{

                Toast.makeText(Add_Contact_Activity.this,"Permission Denied",Toast.LENGTH_LONG).show();
            }


        }else if(requestCode==Image_Permisson_Code){
            if(grantResults.length>=0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){

                Gallery_Open();
            }else{

                Toast.makeText(Add_Contact_Activity.this,"Permission Denied",Toast.LENGTH_LONG).show();
            }

        }


        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Camera_Pic_Code && resultCode == RESULT_OK) {

            Bitmap bitmap_Camera = (Bitmap) data.getExtras().get("data");
            Glide
                    .with(Add_Contact_Activity.this)
                    .load(bitmap_Camera)
                    .override(400,400)
                    .into(AddCon_Image);


        }
        else if(requestCode == Image_Pic_Code && resultCode == RESULT_OK){
            if(data!=null){

                    Uri imgUri = data.getData();
                    CropImage.activity(imgUri)
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setAspectRatio(1,1)
                        .start(this);
//
//                    Glide
//                            .with(Add_Contact_Activity.this)
//                            .load(bitmap_gelory)
//                            .override(400,400)
//                            .into(AddCon_Image);


            }

        }if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();
                Glide
                        .with(Add_Contact_Activity.this)
                        .load(resultUri)
                        .override(400,400)
                        .into(AddCon_Image);
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }



    }



    // Optional.
    public void setProgressBar(){
        progressBar = new ProgressDialog(this);
        progressBar.setCancelable(true);
        progressBar.setMessage("Please wait...");
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressBar.setProgress(0);
        progressBar.setMax(100);
        progressBar.show();
        progressBarStatus = 0;
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (progressBarStatus < 100){
                    progressBarStatus += 30;

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    progressBarbHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setProgress(progressBarStatus);
                        }
                    });
                }
                if (progressBarStatus >= 100) {
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    progressBar.dismiss();
                }

            }
        }).start();
    }

    //For Pick image from Camera or Gelory End----------------------




    public byte[] imageViewToByte(ImageView img){

        Bitmap bitmap =((BitmapDrawable)img.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100,stream);
        byte[] ImagByte =stream.toByteArray();

        return ImagByte;



    }

    // for actionBar show button
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.show_for,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.ShowBut){

            Intent i = new Intent(Add_Contact_Activity.this, MainActivity.class);
            startActivity(i);

        }

        return super.onOptionsItemSelected(item);
    }
    // for actionBar show button End

    // End All
}
