package com.example.lipon.lr_phonebook.model;

/**
 * Created by Lipon on 1/31/2018.
 */

public class Data_sqlite {

    String  id;
    byte[] img;
    String name;
    String phoneNumber;
    String Email;


    public Data_sqlite() {

    }

    // Without All Item
    public Data_sqlite(byte[] img, String name, String phoneNumber, String email,String id) {
        this.img = img;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.Email = email;
        this.id=id;

    }
    // Without Id
    public Data_sqlite(byte[] img,String name, String phoneNumber, String email) {
        this.img = img;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.Email = email;

    }
    // Without Image
    public Data_sqlite(String name, String phoneNumber, String email) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.Email = email;


    }

    public byte[] getImg() {
        return img;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public String getId() {
        return id;
    }

}
