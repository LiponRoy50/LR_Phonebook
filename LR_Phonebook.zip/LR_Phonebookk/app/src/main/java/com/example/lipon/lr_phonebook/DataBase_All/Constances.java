package com.example.lipon.lr_phonebook.DataBase_All;

/**
 * Created by Lipon on 1/31/2018.
 */

public class Constances {

    static final String DATABASE_NAME="MY_DB";
    static final String TABLE_NAME="MY_TABLE";
    static final String KEY_ID = "_id";
    static final int VERSION=1;


    static final String IMAGE_FIELD="MY_Image";
    static final String NAME_FIELD="MY_Name";
    static final String PHONE_NUMBER_FIELD="MY_Phone";
    static final String EMIL_FIELD="MY_Email";


    //Table creation
    static final String Stable = " CREATE TABLE " + TABLE_NAME + " ( "
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + IMAGE_FIELD + " BLOB, "
            + NAME_FIELD + " TEXT, "
            + PHONE_NUMBER_FIELD + " TEXT,"
            + EMIL_FIELD + " TEXT " + ");";



}

//    //Table creation
//    static final String Stable = " CREATE TABLE " + TABLE_NAME + " ( "
//            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
//            + NAME_FIELD + " TEXT, "
//            + ID_FIELD + " TEXT, "
//            + PHONE_NUMBER_FIELD + " TEXT " + ");";
